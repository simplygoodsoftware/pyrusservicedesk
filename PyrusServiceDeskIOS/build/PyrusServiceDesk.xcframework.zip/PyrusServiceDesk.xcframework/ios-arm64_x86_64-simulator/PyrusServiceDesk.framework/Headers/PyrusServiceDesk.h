
#import <UIKit/UIKit.h>
//! Project version number for PyrusServiceDesk.
FOUNDATION_EXPORT double PyrusServiceDeskVersionNumber;

//! Project version string for PyrusServiceDesk.
FOUNDATION_EXPORT const unsigned char PyrusServiceDeskVersionString[];

